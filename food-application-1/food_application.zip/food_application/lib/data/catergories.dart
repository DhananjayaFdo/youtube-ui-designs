import 'package:food_application/models/models.dart';

List<Category> categories =
    [
          {"id": "m_submarine", "title": "Submarine"},
          {"id": "m_burger", "title": "Burgers"},
          {"id": "m_pizza", "title": "Pizza"},
          {"id": "m_salad", "title": "Salads"},
          {"id": "m_bread", "title": "Bread"},
          {"id": "m_rice", "title": "Rice & Bowls"},
          {"id": "m_noodle", "title": "Noodles"},
          {"id": "m_desserts", "title": "Desserts"},
          {"id": "m_bev", "title": "Beverages"},
        ]
        .map(
          (e) => Category.fromJson(e),
        )
        .toList();
