import 'package:food_application/models/models.dart';

List<Product> products =
    [
          {
            "id": "i_pizza_01",
            "menuId": "m_bread",
            "name": "Italian Pepperoni Pizza",
            "price": 18.0,
            "currency": "USD",
            "prepTimeMinutes": 25,
            "rating": 4.7,
            "ratingCount": 236,
            "calories": 780,
            "isVegetarian": false,
            "isFavorite": false,
            "image": "assets/imgs/food-1.png",
            "shortDescription": "Crispy crust pizza loaded with pepperoni, cheese, and olives.",
            "longDescription":
                "Our Italian Pepperoni Pizza is baked to golden perfection with a thin, crispy crust and rich tomato base. Topped with layers of mozzarella cheese, fresh basil, and spicy pepperoni slices for that authentic Italian flavor. The black olives and cherry tomatoes add a delicious tangy twist that balances every bite. Made fresh in our stone oven with premium ingredients. A must-have for pizza lovers who crave bold flavors and perfect texture. Best enjoyed hot and fresh, straight from the oven.",
            "modifiers": [
              {
                "modifierId": "mod_size",
                "title": "Choose Size",
                "type": "single_choice",
                "choices": [
                  {"id": "size_small", "title": "Small (8 inch)", "price": 0},
                  {"id": "size_medium", "title": "Medium (12 inch)", "price": 3},
                  {"id": "size_large", "title": "Large (16 inch)", "price": 5},
                ],
              },
            ],
            "tags": ["pizza", "italian", "baked"],
            "availability": {"available": true, "startsAt": null, "endsAt": null},
          },

          {
            "id": "i_chicken_rice_01",
            "menuId": "m_rice",
            "name": "Grilled Chicken Rice Bowl",
            "price": 13.0,
            "currency": "USD",
            "prepTimeMinutes": 20,
            "rating": 4.5,
            "ratingCount": 198,
            "calories": 650,
            "isVegetarian": false,
            "isFavorite": false,
            "image": "assets/imgs/food-2.png",
            "shortDescription": "Fragrant rice topped with grilled chicken and lime.",
            "longDescription":
                "Our Grilled Chicken Rice Bowl combines juicy marinated chicken drumsticks with aromatic spiced rice. Garnished with fresh basil leaves and lime wedges for a burst of freshness. Each serving is packed with flavor, featuring tender meat cooked to perfection and rice seasoned with subtle herbs and spices. A perfect balance of protein, carbs, and zest in every spoonful. Ideal for both lunch and dinner, giving you the comfort of a homestyle meal with a gourmet touch. Served hot and satisfying.",
            "modifiers": [],
            "tags": ["rice", "chicken", "spicy"],
            "availability": {"available": true},
          },

          {
            "id": "i_burger_01",
            "menuId": "m_submarine",
            "name": "Classic Beef Burger",
            "price": 10.0,
            "currency": "USD",
            "prepTimeMinutes": 15,
            "rating": 4.4,
            "ratingCount": 312,
            "calories": 720,
            "isVegetarian": false,
            "isFavorite": false,
            "image": "assets/imgs/food-3.png",
            "shortDescription": "Juicy beef patty with fresh lettuce, cheese, and tomato.",
            "longDescription":
                "The Classic Beef Burger is everything a true burger should be — juicy, flavorful, and satisfying. A thick grilled beef patty sits between two soft sesame buns layered with melted cheddar cheese, fresh lettuce, tomato, pickles, and our signature sauce. Each bite is a harmony of textures and tastes, from the crisp vegetables to the tender beef. Made with 100% premium ground beef and seasoned to perfection. Served warm, it’s a timeless favorite that never goes out of style.",
            "modifiers": [
              {
                "modifierId": "mod_addons",
                "title": "Add Extras",
                "type": "checkbox",
                "choices": [
                  {"id": "addon_cheese", "title": "Extra Cheese", "price": 1.5},
                  {"id": "addon_bacon", "title": "Bacon", "price": 2.0},
                  {"id": "addon_egg", "title": "Fried Egg", "price": 1.0},
                ],
              },
            ],
            "tags": ["burger", "fastfood", "beef"],
            "availability": {"available": true},
          },

          {
            "id": "i_strawberry_shake_01",
            "menuId": "m_bev",
            "name": "Strawberry Milkshake",
            "price": 6.0,
            "currency": "USD",
            "prepTimeMinutes": 5,
            "rating": 4.8,
            "ratingCount": 142,
            "calories": 430,
            "isVegetarian": true,
            "isFavorite": false,
            "image": "assets/imgs/food-4.png",
            "shortDescription": "Creamy strawberry milkshake topped with whipped cream.",
            "longDescription":
                "Our Strawberry Milkshake is a refreshing blend of real strawberries, creamy milk, and vanilla ice cream — whipped together for the perfect smooth texture. Topped with fluffy whipped cream and a drizzle of strawberry syrup for that sweet finishing touch. Each sip bursts with fruity flavor and creamy richness that melts in your mouth. Served chilled to perfection, it’s both refreshing and indulgent. The perfect companion to your meal or a treat all on its own. Sweet, creamy, and utterly irresistible.",
            "modifiers": [
              {
                "modifierId": "mod_toppings",
                "title": "Extra Toppings",
                "type": "checkbox",
                "choices": [
                  {"id": "top_extra_cream", "title": "Extra Whipped Cream", "price": 0.5},
                  {"id": "top_strawberry", "title": "Extra Strawberry", "price": 0.8},
                ],
              },
            ],
            "tags": ["drink", "dessert", "strawberry"],
            "availability": {"available": true},
          },
        ]
        .map(
          (e) => Product.fromJson(e),
        )
        .toList();
