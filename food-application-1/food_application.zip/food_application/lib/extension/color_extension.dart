import 'package:flutter/material.dart';
import 'package:food_application/services/common/common.dart';

extension MaterialColorGen on Color {
  MaterialColor toMaterialColor() {
    return generateMaterialColor(color: this);
  }
}
