class Imgs {
  static const String profileImage = "assets/img/profile_image.jpeg";
  static const String foodPlate1 = "assets/imgs/food-plate-1.png";
}
