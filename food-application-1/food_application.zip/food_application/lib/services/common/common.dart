export 'package:food_application/services/common/color_generator.dart';
