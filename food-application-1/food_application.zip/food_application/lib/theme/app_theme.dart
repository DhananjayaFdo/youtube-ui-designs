import 'package:flutter/material.dart';
import 'package:food_application/extension/extension.dart';
import 'package:food_application/theme/theme.dart';

abstract class AppTheme {
  static ThemeData lightTheme(BuildContext context) => lightThemeData(context);
}

ThemeData lightThemeData(BuildContext context) => ThemeData(
  primarySwatch: AppColors.primary.toMaterialColor(),
  colorScheme: ColorScheme.fromSwatch(
    errorColor: AppColors.error,
    primarySwatch: AppColors.primary.toMaterialColor(),
  ),
  scaffoldBackgroundColor: AppColors.white,
  dividerColor: AppColors.grey30,
  useMaterial3: true,
  textTheme: const AppTextTheme.fallback().toTextTheme(),
  // AppBar Theme
  appBarTheme: AppBarTheme(
    backgroundColor: Colors.transparent,
    iconTheme: const IconThemeData(color: AppColors.black),
    centerTitle: true,
    titleTextStyle: const AppTextTheme().large,
    elevation: 0,
  ),
  bottomAppBarTheme: const BottomAppBarTheme(color: Colors.transparent, elevation: 0),

  /// Input Decoration Theme
  inputDecorationTheme: InputDecorationTheme(
    labelStyle: AppTextTheme().large,
    hintStyle: AppTextTheme().large,
    errorStyle: AppTextTheme().large,
    contentPadding: EdgeInsets.all(0),
    isCollapsed: true,
    border: InputBorder.none,
    enabledBorder: InputBorder.none,
    focusedBorder: InputBorder.none,
    errorBorder: InputBorder.none,
    focusedErrorBorder: InputBorder.none,
  ),
  dividerTheme: const DividerThemeData(thickness: 1, color: AppColors.grey20),
  checkboxTheme: const CheckboxThemeData(
    side: BorderSide(color: AppColors.grey20),
  ),
  textButtonTheme: TextButtonThemeData(
    style: TextButton.styleFrom(foregroundColor: AppColors.primary),
  ),
  badgeTheme: const BadgeThemeData(
    backgroundColor: AppColors.error,
  ),
  filledButtonTheme: FilledButtonThemeData(
    style: ButtonStyle(
      backgroundColor: WidgetStatePropertyAll(AppColors.primary),
      shape: WidgetStatePropertyAll(
        RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
      ),
      textStyle: WidgetStatePropertyAll(AppTextTheme().large),
      alignment: Alignment.center,
      minimumSize: WidgetStatePropertyAll(Size(double.maxFinite, 50)),
    ),
  ),
);
