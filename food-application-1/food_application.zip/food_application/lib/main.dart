import 'package:flutter/material.dart';
import 'package:food_application/extension/extension.dart';
import 'package:food_application/theme/theme.dart';

void main() => runApp(AppStructure());

class AppStructure extends StatelessWidget {
  const AppStructure({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: AppTheme.lightTheme(context),
      home: Scaffold(
        body: Center(child: Text("Welcome", style: context.textStyleXtraLarge)),
      ),
    );
  }
}
