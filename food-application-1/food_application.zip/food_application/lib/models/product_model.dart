class Product {
  String id;
  String menuId;
  String name;
  double price;
  String currency;
  int prepTimeMinutes;
  double rating;
  int ratingCount;
  int calories;
  bool isVegetarian;
  bool isFavorite;
  String image;
  String shortDescription;
  String longDescription;
  List<Modifier> modifiers;
  List<String> tags;
  Availability availability;

  Product({
    required this.id,
    required this.menuId,
    required this.name,
    required this.price,
    required this.currency,
    required this.prepTimeMinutes,
    required this.rating,
    required this.ratingCount,
    required this.calories,
    required this.isVegetarian,
    required this.isFavorite,
    required this.image,
    required this.shortDescription,
    required this.longDescription,
    required this.modifiers,
    required this.tags,
    required this.availability,
  });

  factory Product.fromJson(Map<String, dynamic> json) => Product(
    id: json["id"],
    menuId: json["menuId"],
    name: json["name"],
    price: json["price"],
    currency: json["currency"],
    prepTimeMinutes: json["prepTimeMinutes"],
    rating: json["rating"]?.toDouble(),
    ratingCount: json["ratingCount"],
    calories: json["calories"],
    isVegetarian: json["isVegetarian"],
    isFavorite: json["isFavorite"],
    image: json["image"],
    shortDescription: json["shortDescription"],
    longDescription: json["longDescription"],
    modifiers: List<Modifier>.from(json["modifiers"].map((x) => Modifier.fromJson(x))),
    tags: List<String>.from(json["tags"].map((x) => x)),
    availability: Availability.fromJson(json["availability"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "menuId": menuId,
    "name": name,
    "price": price,
    "currency": currency,
    "prepTimeMinutes": prepTimeMinutes,
    "rating": rating,
    "ratingCount": ratingCount,
    "calories": calories,
    "isVegetarian": isVegetarian,
    "isFavorite": isFavorite,
    "image": image,
    "shortDescription": shortDescription,
    "longDescription": longDescription,
    "modifiers": List<dynamic>.from(modifiers.map((x) => x.toJson())),
    "tags": List<dynamic>.from(tags.map((x) => x)),
    "availability": availability.toJson(),
  };
}

class Availability {
  bool available;
  dynamic startsAt;
  dynamic endsAt;

  Availability({
    required this.available,
    this.startsAt,
    this.endsAt,
  });

  factory Availability.fromJson(Map<String, dynamic> json) => Availability(
    available: json["available"],
    startsAt: json["startsAt"],
    endsAt: json["endsAt"],
  );

  Map<String, dynamic> toJson() => {
    "available": available,
    "startsAt": startsAt,
    "endsAt": endsAt,
  };
}

class Modifier {
  String modifierId;
  String title;
  String type;
  List<Choice> choices;

  Modifier({
    required this.modifierId,
    required this.title,
    required this.type,
    required this.choices,
  });

  factory Modifier.fromJson(Map<String, dynamic> json) => Modifier(
    modifierId: json["modifierId"],
    title: json["title"],
    type: json["type"],
    choices: List<Choice>.from(json["choices"].map((x) => Choice.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "modifierId": modifierId,
    "title": title,
    "type": type,
    "choices": List<dynamic>.from(choices.map((x) => x.toJson())),
  };
}

class Choice {
  String id;
  String title;
  double price;

  Choice({
    required this.id,
    required this.title,
    required this.price,
  });

  factory Choice.fromJson(Map<String, dynamic> json) => Choice(
    id: json["id"],
    title: json["title"],
    price: json["price"]?.toDouble(),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "price": price,
  };
}
